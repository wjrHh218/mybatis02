create trigger ab
  after INSERT
  on b
  for each row
  begin
update a set num=num-new.num where id=new.aid;
end;

