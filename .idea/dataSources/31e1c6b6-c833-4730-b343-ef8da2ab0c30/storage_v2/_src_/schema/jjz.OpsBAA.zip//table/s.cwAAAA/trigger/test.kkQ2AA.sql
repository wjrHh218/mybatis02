create trigger test
  before INSERT
  on s
  for each row
  begin
insert into s values (2,45.32);
end;

